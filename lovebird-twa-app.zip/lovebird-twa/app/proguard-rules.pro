# ProGuard rules for Lovebird Genetics TWA
# Obfuscates and shrinks code to protect against reverse engineering

# Keep TWA library classes intact
-keep class com.google.androidbrowserhelper.** { *; }
-keep class androidx.browser.** { *; }

# Keep app entry point
-keep class com.lovebirdgenetics.app.** { *; }

# Standard Android rules
-keepattributes *Annotation*
-keepattributes SourceFile,LineNumberTable
-keep public class * extends java.lang.Exception

# Aggressive obfuscation
-repackageclasses ''
-allowaccessmodification
-optimizationpasses 5

# Remove logging in release builds
-assumenosideeffects class android.util.Log {
    public static boolean isLoggable(java.lang.String, int);
    public static int v(...);
    public static int i(...);
    public static int w(...);
    public static int d(...);
    public static int e(...);
}
