# Lovebird Genetics — Play Store Submission Guide

## What this app is
A TWA (Trusted Web Activity) — a thin Android shell that loads lovebirdgenetics.com.
- Auto-updates when you push to GitHub (no Play Store update needed)
- Works online only — no offline mode
- Code is obfuscated with ProGuard (genetics engine lives on Netlify, not in APK)

---

## STEP 1 — Install Android Studio (if not installed)
Download: https://developer.android.com/studio
Install, open it, let it download SDK components (takes ~10 min).

---

## STEP 2 — Open this project
1. Open Android Studio
2. File → Open → select this `lovebird-twa` folder
3. Wait for Gradle sync to finish (first time ~5 min, downloads dependencies)

---

## STEP 3 — Add app icons via Image Asset tool
1. Right-click `app/src/main/res` → New → Image Asset
2. Icon type: Launcher Icons (Adaptive and Legacy)
3. Foreground layer: Image → browse to `icon-512.png` from the lovebirdgenetics.com folder
4. Background layer: Color → enter `#141414`
5. Click Next → Finish
(This replaces the placeholder icons with perfect-quality ones)

---

## STEP 4 — Create Play Console account
1. Go to: https://play.google.com/console
2. Sign in with your Google account
3. Pay the one-time $25 USD developer fee
4. Accept Developer Distribution Agreement

---

## STEP 5 — Create the app in Play Console
1. Click "Create app"
2. App name: `Lovebird Genetics Calculator`
3. Default language: English (United States)
4. App or game: App
5. Free or paid: Free
6. Accept policies → Create app

---

## STEP 6 — Get SHA-256 fingerprint (CRITICAL for TWA)
1. In Play Console → your app → Setup → App signing
2. Copy the **SHA-256 certificate fingerprint** (looks like: `AB:CD:EF:12:...`)
3. Open `/sessions/.../lovebirdgenetics.com/.well-known/assetlinks.json`
4. Replace `"YOUR_SHA256_FINGERPRINT_HERE"` with your actual fingerprint
5. Push to GitHub → Netlify deploys → wait ~2 min
6. Verify at: https://digitalassetlinks.googleapis.com/v1/statements:list?source.web.site=https://lovebirdgenetics.com&relation=delegate_permission/common.handle_all_urls

---

## STEP 7 — Build the signed AAB
1. In Android Studio: Build → Generate Signed Bundle/APK
2. Choose: Android App Bundle (AAB) — required by Play Store
3. Create new keystore:
   - Path: save somewhere safe (e.g., Desktop/lovebird-release.jks)
   - Password: choose strong password
   - Key alias: `lovebird`
   - Fill in your name/organization
4. Build type: release
5. Click Finish → wait for build
6. AAB file will be at: `app/release/app-release.aab`

---

## STEP 8 — Fill out Play Store listing
Go to Play Console → your app and fill:

**Main store listing:**
- Title: `Lovebird Genetics Calculator`
- Short description: `Predict lovebird offspring mutations instantly — Opaline, Aqua, Pale Fallow & more`
- Full description: (see below)

**Full description (copy-paste):**
```
Lovebird Genetics Calculator by KinBird Aviary — the most accurate free tool for predicting lovebird offspring mutations.

Select your male and female birds, and instantly see all possible offspring with exact percentages. Supports every major mutation including:

• Opaline (sex-linked)
• Aqua B1, B2, and Homo
• Pale Fallow & Dun Fallow
• Lutino / Albino (Ino)
• Violet, Dark Factor
• YellowFace series
• Cinnamon, Dilute
• Pied, and more

Built by an active lovebird breeder in Bangladesh who sources rare mutations from Indonesia and the Philippines. The genetics engine is used by breeders in over 30 countries.

No account needed. No ads. Always free.

Requires internet connection.
```

**Graphics needed:**
- App icon: 512×512 PNG (use icon-512.png)
- Feature graphic: 1024×500 PNG (we can create this)
- Screenshots: at least 2 phone screenshots (take them from lovebirdgenetics.com on mobile)

---

## STEP 9 — Upload AAB and submit
1. Production → Create new release
2. Upload your `.aab` file
3. Release name: `1.0.0`
4. Release notes: `Initial release — predict lovebird offspring mutations instantly`
5. Review and submit

**Review time: typically 3–7 days for first submission. Expedited review is not available.**

---

## After approval — how updates work
1. You change code → push to GitHub
2. Netlify auto-deploys (2 min)
3. App users see new version instantly — NO Play Store update needed
4. Only update Play Store AAB when you change native app features (rare)

---

## Important files reference
- `assetlinks.json` location: `lovebirdgenetics.com/.well-known/assetlinks.json`
- Must be live at: `https://lovebirdgenetics.com/.well-known/assetlinks.json`
- Without correct SHA-256 in this file, the app will open in browser instead of TWA mode
